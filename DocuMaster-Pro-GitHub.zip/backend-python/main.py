from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse
import shutil
import os
import fitz  # PyMuPDF for editing text & signatures
from pypdf import PdfWriter, PdfReader
from pdf2docx import Converter

app = FastAPI(title="DocuMaster Pro Engine")
UPLOAD_DIR = "temp_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/pdf-to-word")
async def pdf_to_word(file: UploadFile = File(...)):
    pdf_path = os.path.join(UPLOAD_DIR, file.filename)
    docx_path = pdf_path.replace(".pdf", ".docx")
    with open(pdf_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    cv = Converter(pdf_path)
    cv.convert(docx_path, start=0, end=None)
    cv.close()
    return FileResponse(docx_path, filename=os.path.basename(docx_path))

@app.post("/merge-pdfs")
async def merge_pdfs(files: list[UploadFile] = File(...)):
    merger = PdfWriter()
    for file in files:
        path = os.path.join(UPLOAD_DIR, file.filename)
        with open(path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        merger.append(path)
    
    output_path = os.path.join(UPLOAD_DIR, "merged_output.pdf")
    merger.write(output_path)
    merger.close()
    return FileResponse(output_path, filename="merged_output.pdf")

@app.post("/add-text")
async def add_text_to_pdf(
    file: UploadFile = File(...),
    page_num: int = Form(0),
    text: str = Form(...),
    x: float = Form(100),
    y: float = Form(100)
):
    pdf_path = os.path.join(UPLOAD_DIR, file.filename)
    output_path = os.path.join(UPLOAD_DIR, f"edited_{file.filename}")
    with open(pdf_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    doc = fitz.open(pdf_path)
    page = doc[page_num]
    page.insert_text((x, y), text, fontsize=12, color=(0, 0, 0))
    doc.save(output_path)
    doc.close()
    return FileResponse(output_path, filename=f"edited_{file.filename}")

@app.post("/add-signature")
async def add_signature(
    pdf_file: UploadFile = File(...),
    sig_image: UploadFile = File(...),
    page_num: int = Form(0),
    x: float = Form(100),
    y: float = Form(100),
    width: float = Form(150),
    height: float = Form(50)
):
    pdf_path = os.path.join(UPLOAD_DIR, pdf_file.filename)
    sig_path = os.path.join(UPLOAD_DIR, sig_image.filename)
    output_path = os.path.join(UPLOAD_DIR, f"signed_{pdf_file.filename}")
    
    with open(pdf_path, "wb") as b1, open(sig_path, "wb") as b2:
        shutil.copyfileobj(pdf_file.file, b1)
        shutil.copyfileobj(sig_image.file, b2)
        
    doc = fitz.open(pdf_path)
    page = doc[page_num]
    rect = fitz.Rect(x, y, x + width, y + height)
    page.insert_image(rect, filename=sig_path)
    doc.save(output_path)
    doc.close()
    return FileResponse(output_path, filename=f"signed_{pdf_file.filename}")
