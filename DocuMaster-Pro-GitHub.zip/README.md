# DocuMaster Pro (Adobe Acrobat Alternative)

Cross-platform PDF & Word Utility built for **Windows PC** and **Android** with an **English UI**.

## Features
1. **Word to PDF & PDF to Word Conversion**
2. **Edit PDF Text & Annotations**
3. **Add Digital & Drawn Signatures**
4. **Merge & Split PDF Files**
5. **Cross-Platform Support** (Flutter Frontend for Android & Windows + Python FastAPI Processing Engine)

## Project Structure
- `frontend-flutter/`: Cross-platform UI written in Flutter (compiles to Windows `.exe` and Android `.apk`).
- `backend-python/`: Core document conversion and manipulation API using `pdf2docx`, `pypdf`, `reportlab`, and `LibreOffice/docx2pdf`.
- `.github/workflows/`: Automated CI/CD workflow to build the app when pushed to GitHub.

## How to Run Locally
### 1. Backend
```bash
cd backend-python
pip install -r requirements.txt
uvicorn main:app --reload
```

### 2. Frontend (Flutter)
```bash
cd frontend-flutter
flutter pub get
flutter run -d windows # Or -d android
```
