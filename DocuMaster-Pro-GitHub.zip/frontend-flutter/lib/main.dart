import 'package:flutter/material.dart';

void main() {
  runApp(const DocuMasterApp());
}

class DocuMasterApp extends StatelessWidget {
  const DocuMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DocuMaster Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFB30B00)),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedTool = 'Dashboard';

  final List<Map<String, dynamic>> _tools = [
    {'title': 'PDF to Word', 'icon': Icons.description, 'desc': 'Convert PDF documents to editable DOCX'},
    {'title': 'Word to PDF', 'icon': Icons.picture_as_pdf, 'desc': 'Convert DOCX files into standard PDF'},
    {'title': 'Edit PDF Text', 'icon': Icons.edit_document, 'desc': 'Modify or insert text directly into PDF'},
    {'title': 'Sign PDF', 'icon': Icons.draw, 'desc': 'Draw or upload your digital signature'},
    {'title': 'Merge PDFs', 'icon': Icons.merge_type, 'desc': 'Combine multiple PDF files into one'},
    {'title': 'Split & Organize', 'icon': Icons.call_split, 'desc': 'Extract, reorder, or delete PDF pages'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DocuMaster Pro - PDF & Word Suite', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFFB30B00),
        actions: [
          IconButton(
            icon: const Icon(Icons.folder_open, color: Colors.white),
            tooltip: 'Open File',
            onPressed: () {},
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Color(0xFFB30B00)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Icon(Icons.picture_as_pdf, color: Colors.white, size: 48),
                  SizedBox(height: 10),
                  Text('DocuMaster Pro', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  Text('Windows & Android Edition', style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
            ..._tools.map((tool) => ListTile(
              leading: Icon(tool['icon'], color: const Color(0xFFB30B00)),
              title: Text(tool['title']),
              onTap: () {
                setState(() => _selectedTool = tool['title']);
                Navigator.pop(context);
              },
            )),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _selectedTool == 'Dashboard' ? 'All PDF & Word Tools' : _selectedTool,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text('Select a tool below to start converting, editing, or signing your documents.'),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 280,
                  childAspectRatio: 1.2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: _tools.length,
                itemBuilder: (context, index) {
                  final tool = _tools[index];
                  return Card(
                    elevation: 3,
                    child: InkWell(
                      onTap: () => _showToolDialog(context, tool['title']),
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(tool['icon'], size: 42, color: const Color(0xFFB30B00)),
                            const SizedBox(height: 12),
                            Text(tool['title'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Text(tool['desc'], textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showToolDialog(BuildContext context, String toolName) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(toolName),
        content: Text('Select a file from your device to process with $toolName.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload_file),
            label: const Text('Choose File'),
            onPressed: () => Navigator.pop(ctx),
          ),
        ],
      ),
    );
  }
}
